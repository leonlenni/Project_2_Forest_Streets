# -*- coding: utf-8 -*-

import os
import processing
from qgis.core import (
    QgsProject,
    QgsVectorLayer,
    QgsFeature,
    QgsVectorFileWriter
)

# -------- OUTPUT DIRECTORY --------
output_folder = "/Users/leonhofmann/Desktop/MMES/Protject 2/QGIS/QGISOutput"

# -------- LOAD LAYERS --------
tile_layer = QgsProject.instance().mapLayersByName('overlap_raster_template_64x64')[0]
roads_layer = QgsProject.instance().mapLayersByName('Polygon_Annotation_Adrian')[0]
hillshade = QgsProject.instance().mapLayersByName('Hillshade_Sattelmuehle')[0]

# -------- FIX ROAD GEOMETRIES --------
roads_layer_fixed = processing.run(
    "native:fixgeometries",
    {'INPUT': roads_layer, 'OUTPUT':'memory:'}
)['OUTPUT']

# -------- ENSURE SAME CRS --------
target_crs = tile_layer.crs().authid()

if roads_layer_fixed.crs().authid() != target_crs:
    roads_layer_fixed = processing.run(
        "native:reprojectlayer",
        {
            'INPUT': roads_layer_fixed,
            'TARGET_CRS': target_crs,
            'OUTPUT':'memory:'
        }
    )['OUTPUT']

if hillshade.crs().authid() != target_crs:
    hillshade = processing.run(
        "native:reprojectlayer",
        {
            'INPUT': hillshade,
            'TARGET_CRS': target_crs,
            'OUTPUT':'memory:'
        }
    )['OUTPUT']

# -------- GET UNIQUE STATUS VALUES (ignore 0) --------
status_values = set([f['Status'] for f in tile_layer.getFeatures() if f['Status'] != 0])
print("Found Status values (ignoring 0):", status_values)

# -------- PROCESS TILES BY STATUS --------
for status in status_values:
    status_folder = os.path.join(output_folder, f"Status{status}")
    images_folder = os.path.join(status_folder, "images")
    labels_folder = os.path.join(status_folder, "labels")
    os.makedirs(images_folder, exist_ok=True)
    os.makedirs(labels_folder, exist_ok=True)

    print(f"\nProcessing Status {status} tiles...")

    tile_count = 0
    for tile in tile_layer.getFeatures():
        if tile['Status'] != status:
            continue  # skip tiles of other statuses

        tile_count += 1
        print(f"  Tile {tile_count} (ID {tile.id()})")

        # Create tile memory layer
        tile_layer_temp = QgsVectorLayer(
            "Polygon?crs=" + target_crs,
            "tile",
            "memory"
        )
        prov = tile_layer_temp.dataProvider()
        new_feat = QgsFeature(tile)
        prov.addFeatures([new_feat])
        tile_layer_temp.updateExtents()

        # Clip roads
        clipped_roads = processing.run(
            "native:clip",
            {
                'INPUT': roads_layer_fixed,
                'OVERLAY': tile_layer_temp,
                'OUTPUT':'memory:'
            }
        )['OUTPUT']

        # Skip if no roads
        if clipped_roads.featureCount() == 0:
            print("    No roads in this tile, skipping.")
            continue

        # Clip hillshade raster
        raster_output = os.path.join(images_folder, f"image_{tile.id()}.tif")
        processing.run(
            "gdal:cliprasterbymasklayer",
            {
                'INPUT': hillshade,
                'MASK': tile_layer_temp,
                'CROP_TO_CUTLINE': True,
                'OUTPUT': raster_output
            }
        )

        # Save clipped roads as GeoJSON
        geojson_output = os.path.join(labels_folder, f"image_{tile.id()}.geojson")
        QgsVectorFileWriter.writeAsVectorFormat(
            clipped_roads,
            geojson_output,
            "UTF-8",
            clipped_roads.crs(),
            "GeoJSON"
        )
        print(f"    Saved raster and GeoJSON for tile {tile.id()}")

print("\nFinished! Data saved in:", output_folder)