#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Batch conversion of TIFF to PNG
PNG files are saved in the corresponding output folder.
"""

#!/usr/bin/env python3
import rasterio
import numpy as np
import cv2
from pathlib import Path

# Source folder with sampled TIFFs
source_folder = Path("/Users/leonhofmann/Desktop/MMES/Protject 2/Yolo11/TestData/images_raw")

# Destination folder for PNGs
dest_folder = source_folder.parent / "image"
dest_folder.mkdir(parents=True, exist_ok=True)

# Loop through all TIFFs in source folder
for tif_file in source_folder.glob("*.tif"):
    # Open raster
    with rasterio.open(tif_file) as src:
        if src.count >= 3:
            img = np.dstack([src.read(1), src.read(2), src.read(3)])
        else:
            img = src.read(1)
            # Fake 3 channels for YOLO
            img = np.stack([img]*3, axis=-1)

        # Convert to uint8 if necessary
        if img.dtype != np.uint8:
            img_min = img.min()
            img_max = img.max()
            if img_max > img_min:
                img = ((img - img_min) / (img_max - img_min) * 255).astype(np.uint8)
            else:
                img = np.zeros_like(img, dtype=np.uint8)

    # Save PNG in destination folder
    png_path = dest_folder / (tif_file.stem + ".png")
    cv2.imwrite(str(png_path), cv2.cvtColor(img, cv2.COLOR_RGB2BGR))
    print("Saved PNG:", png_path)

print("Finished converting all TIFFs in images_raw to PNGs in 'image' folder.")