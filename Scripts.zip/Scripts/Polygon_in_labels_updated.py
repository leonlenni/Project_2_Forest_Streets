#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Convert YOLO segmentation predictions (.txt) to GeoJSON with world coordinates.
Each YOLO prediction line is expected in format:
<class_id> x1 y1 x2 y2 x3 y3 ...
Coordinates are normalized [0,1] relative to image size.

Output is QGIS-compatible GeoJSON with MultiPolygon geometries and proper CRS.
"""
import json
from pathlib import Path
import rasterio

# ----------------------
# User settings
# ----------------------
predictions_dir = Path("/Users/leonhofmann/Desktop/MMES/Protject 2/Yolo11/predictions/predict2/labels")
tiff_dir = Path("/Users/leonhofmann/Desktop/MMES/Protject 2/Yolo11/TestData/images_raw")
output_geojson_dir = Path("/Users/leonhofmann/Desktop/MMES/Protject 2/Yolo11/predictions/labels_worldcoordinates")
output_geojson_dir.mkdir(parents=True, exist_ok=True)

# Optional: map class ID to your RoadTyp if different
class_to_roadtyp = {
    0: 0,
    1: 1,
    2: 2
}

# ----------------------
# Conversion
# ----------------------
for yolo_file in predictions_dir.glob("*.txt"):
    raster_file = tiff_dir / f"{yolo_file.stem}.tif"
    output_geojson_file = output_geojson_dir / f"{yolo_file.stem}.geojson"

    if not raster_file.exists():
        print(f"Skipping {yolo_file.stem}, TIFF not found")
        continue

    with rasterio.open(raster_file) as src:
        transform = src.transform
        width = src.width
        height = src.height
        epsg = src.crs.to_epsg()

    features = []

    with open(yolo_file) as f:
        for line in f:
            parts = line.strip().split()
            if len(parts) < 7:  # at least 3 points needed for a polygon
                continue

            class_id = int(parts[0])
            coords = list(map(float, parts[1:]))

            # normalized -> pixel
            pixel_coords = [(x * width, y * height) for x, y in zip(coords[::2], coords[1::2])]

            # pixel -> world
            world_coords = [list(transform * (px, py)) for px, py in pixel_coords]

            # close polygon
            if world_coords[0] != world_coords[-1]:
                world_coords.append(world_coords[0])

            # MultiPolygon format
            feature = {
                "type": "Feature",
                "properties": {"RoadTyp": class_to_roadtyp.get(class_id, 0)},
                "geometry": {
                    "type": "MultiPolygon",
                    "coordinates": [[world_coords]]
                }
            }

            features.append(feature)

    geojson = {
        "type": "FeatureCollection",
        "name": yolo_file.stem,
        "crs": {
            "type": "name",
            "properties": {"name": f"urn:ogc:def:crs:EPSG::{epsg}"}
        },
        "features": features
    }

    with open(output_geojson_file, "w") as f:
        json.dump(geojson, f, indent=2)

    print(f"GeoJSON saved: {output_geojson_file}")