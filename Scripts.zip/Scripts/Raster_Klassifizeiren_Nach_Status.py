# -*- coding: utf-8 -*-
import processing
from qgis.core import QgsProject, QgsVectorLayer, QgsFeature

# -------- LOAD LAYERS --------
tile_layer = QgsProject.instance().mapLayersByName('overlap_raster_template_64x64')[0]
roads_layer = QgsProject.instance().mapLayersByName('Polygon_Annotation_Adrian')[0]

# -------- FIX ROAD GEOMETRIES --------
roads_layer_fixed = processing.run(
    "native:fixgeometries",
    {'INPUT': roads_layer, 'OUTPUT':'memory:'}
)['OUTPUT']

# -------- GET STATUS FIELD INDEX --------
status_idx = tile_layer.fields().indexFromName('Status')
if status_idx == -1:
    raise Exception("Feld 'Status' existiert nicht im Tile-Layer!")

# -------- PROCESS TILES --------
for tile in tile_layer.getFeatures():
    # -------- CREATE TILE MEMORY LAYER --------
    tile_layer_temp = QgsVectorLayer(
        "Polygon?crs=" + tile_layer.crs().authid(),
        "tile",
        "memory"
    )
    prov = tile_layer_temp.dataProvider()
    prov.addFeatures([QgsFeature(tile)])
    tile_layer_temp.updateExtents()

    # -------- CLIP ROADS IN TILE --------
    clipped_roads = processing.run(
        "native:clip",
        {'INPUT': roads_layer_fixed, 'OVERLAY': tile_layer_temp, 'OUTPUT':'memory:'}
    )['OUTPUT']

    # -------- STATUS KATEGORISIERUNG --------
    road_types = [f['RoadTyp'] for f in clipped_roads.getFeatures()]
    unique_types = set(road_types)

    if len(unique_types) == 0:
        status = 0
    elif unique_types <= {0}:
        status = 1
    elif unique_types <= {0,1} and 1 in unique_types:
        status = 2
    elif unique_types <= {0,2} and 2 in unique_types:
        status = 3
    elif unique_types >= {1,2,3}:
        status = 4
    else:
        status = 0

    # -------- UPDATE STATUS IN TILE LAYER --------
    tile_layer.startEditing()
    tile_layer.changeAttributeValue(tile.id(), status_idx, status)
    tile_layer.commitChanges()

    print(f"Tile {tile['id'] if 'id' in tile.fields().names() else tile.id()}: Status {status}")

print("Finished! Tiles classified.")