"""
#This script copies images and labels from Status folders into YOLO train and validation directories, 
splitting 80% for training and 20% for validation.

Tries to ensure equal consideration of each road type for training, however rarer street types (skid and hiking trail)
are ofthe mixed with firest road so still skewed (maybe more detailed selection  needed)

1 –  Forest Road
2 –  Hiking + Road
3 –  Skid trail + Road
4 - True Positive All (doesnt exist in the example workflow)
"""
import os
import shutil
from glob import glob

# Source base folder (Status1, Status2, Status3)
source_base = "/Users/leonhofmann/Desktop/MMES/Protject 2/QGIS/QGISOutput"

# Destination folders
dest_images_train = "/Users/leonhofmann/Desktop/MMES/Protject 2/Yolo11/TrainingData/images_raw/train"
dest_images_val = "/Users/leonhofmann/Desktop/MMES/Protject 2/Yolo11/TrainingData/images_raw/val"
dest_labels_train = "/Users/leonhofmann/Desktop/MMES/Protject 2/Yolo11/TrainingData/labels_raw/train"
dest_labels_val = "/Users/leonhofmann/Desktop/MMES/Protject 2/Yolo11/TrainingData/labels_raw/val"

# Ensure destination folders exist
for folder in [dest_images_train, dest_images_val, dest_labels_train, dest_labels_val]:
    os.makedirs(folder, exist_ok=True)

# Status folders to copy
status_list = ["Status1", "Status2", "Status3"]

# Function to copy files with train/val split
def copy_files(src_folder, dest_train, dest_val, ext="*"):
    files = sorted(glob(os.path.join(src_folder, f"{ext}")))  # sorted to keep consistent order
    train_files = files[:200]   # first 80 files
    val_files = files[200:100]  # next 20 files
    
    for f in train_files:
        shutil.copy(f, dest_train)
    for f in val_files:
        shutil.copy(f, dest_val)

# Loop through each status
for status in status_list:
    images_src = os.path.join(source_base, status, "images")
    labels_src = os.path.join(source_base, status, "labels")
    
    # Copy images
    copy_files(images_src, dest_images_train, dest_images_val, ext="*.tif")
    # Copy labels
    copy_files(labels_src, dest_labels_train, dest_labels_val, ext="*.geojson")

print("Finished copying files with train/validation split.")