"""
Randomly sample image/label pairs from Status folders and split into
200 training and 60 validation samples per status.

Ensures:
- images and labels correspond (same filename)
- no duplicates
- random sampling
"""

import os
import shutil
import random
from glob import glob

# reproducible random sampling (optional)
random.seed(42)

source_base = "/Users/leonhofmann/Desktop/MMES/Protject 2/QGIS/QGISOutput"

dest_images_train = "/Users/leonhofmann/Desktop/MMES/Protject 2/Yolo11/TrainingData/images_raw/train"
dest_images_val = "/Users/leonhofmann/Desktop/MMES/Protject 2/Yolo11/TrainingData/images_raw/val"
dest_labels_train = "/Users/leonhofmann/Desktop/MMES/Protject 2/Yolo11/TrainingData/labels_raw/train"
dest_labels_val = "/Users/leonhofmann/Desktop/MMES/Protject 2/Yolo11/TrainingData/labels_raw/val"

for folder in [dest_images_train, dest_images_val, dest_labels_train, dest_labels_val]:
    os.makedirs(folder, exist_ok=True)

status_list = ["Status1", "Status2", "Status3"]

TRAIN_COUNT = 120
VAL_COUNT = 20
REQUIRED = TRAIN_COUNT + VAL_COUNT

for status in status_list:

    images_src = os.path.join(source_base, status, "images")
    labels_src = os.path.join(source_base, status, "labels")

    image_files = glob(os.path.join(images_src, "*.tif"))

    pairs = []

    # build valid image/label pairs
    for img in image_files:
        name = os.path.splitext(os.path.basename(img))[0]
        label = os.path.join(labels_src, name + ".geojson")

        if os.path.exists(label):
            pairs.append((img, label))

    # explicit error check
    if len(pairs) < REQUIRED:
        raise ValueError(
            f"{status} only has {len(pairs)} valid image/label pairs, "
            f"but {REQUIRED} are required "
            f"(train={TRAIN_COUNT}, val={VAL_COUNT})."
        )

    # randomize
    random.shuffle(pairs)

    train_pairs = pairs[:TRAIN_COUNT]
    val_pairs = pairs[TRAIN_COUNT:TRAIN_COUNT + VAL_COUNT]

    # copy train
    for img, lbl in train_pairs:
        shutil.copy(img, dest_images_train)
        shutil.copy(lbl, dest_labels_train)

    # copy val
    for img, lbl in val_pairs:
        shutil.copy(img, dest_images_val)
        shutil.copy(lbl, dest_labels_val)

print("Finished random sampling and copying files.")