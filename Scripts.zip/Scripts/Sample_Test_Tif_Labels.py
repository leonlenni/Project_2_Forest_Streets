#!/usr/bin/env python3
import os
import shutil
import random
from glob import glob
from pathlib import Path

# Reproducible sampling
random.seed(42)

# Source base folder
source_base = "/Users/leonhofmann/Desktop/MMES/Protject 2/QGIS/QGISOutput"

# Destination folders
dest_images = "/Users/leonhofmann/Desktop/MMES/Protject 2/Yolo11/TestData/images_raw"
dest_labels = "/Users/leonhofmann/Desktop/MMES/Protject 2/Yolo11/TestData/labels"

# Ensure destination folders exist
for folder in [dest_images, dest_labels]:
    os.makedirs(folder, exist_ok=True)

# Status folders
status_list = ["Status1", "Status2", "Status3"]

TEST_COUNT = 20

pairs = []

# Collect valid image/label pairs
for status in status_list:

    images_src = os.path.join(source_base, status, "images")
    labels_src = os.path.join(source_base, status, "labels")

    image_files = glob(os.path.join(images_src, "*.tif"))

    for img in image_files:
        name = Path(img).stem
        label = os.path.join(labels_src, name + ".geojson")

        pairs.append((img, label))

# Shuffle all available samples
random.shuffle(pairs)

# Select test subset
test_pairs = pairs[:TEST_COUNT]

# Copy files
for img, lbl in test_pairs:

    base_name = Path(img).name
    shutil.copy(img, os.path.join(dest_images, base_name))

    if os.path.exists(lbl):
        shutil.copy(lbl, os.path.join(dest_labels, Path(lbl).name))
    else:
        # create empty label if none exists
        Path(os.path.join(dest_labels, Path(img).stem + ".geojson")).touch()

print(f"Finished copying {TEST_COUNT} random samples into test dataset.")