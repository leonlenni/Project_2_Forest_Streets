# -*- coding: utf-8 -*-

import os
import processing
from qgis.core import (
    QgsProject,
    QgsVectorLayer,
    QgsFeature,
    QgsVectorFileWriter
)

# -------- OUTPUT DIRECTORY --------
output_folder = "/Users/leonhofmann/Desktop/MMES/Protject 2/QGIS/TestOutput"
images_folder = os.path.join(output_folder, "images")
labels_folder = os.path.join(output_folder, "labels")

#creates new directory if not exists
os.makedirs(images_folder, exist_ok=True)
os.makedirs(labels_folder, exist_ok=True)

# -------- LOAD LAYERS --------
tile_layer = QgsProject.instance().mapLayersByName('Grid_Sattelmuehle_learning')[0]
roads_layer = QgsProject.instance().mapLayersByName('Polygon_Annotation_Adrian')[0]
hillshade = QgsProject.instance().mapLayersByName('Hillshade_Sattelmuehle')[0]

# -------- FIX ROAD GEOMETRIES --------
roads_layer_fixed = processing.run(
    "native:fixgeometries",
    {'INPUT': roads_layer, 'OUTPUT':'memory:'}
)['OUTPUT']

# -------- ENSURE SAME CRS --------
target_crs = tile_layer.crs().authid()

if roads_layer_fixed.crs().authid() != target_crs:
    roads_layer_fixed = processing.run(
        "native:reprojectlayer",
        {
            'INPUT': roads_layer_fixed,
            'TARGET_CRS': target_crs,
            'OUTPUT':'memory:'
        }
    )['OUTPUT']

if hillshade.crs().authid() != target_crs:
    hillshade = processing.run(
        "native:reprojectlayer",
        {
            'INPUT': hillshade,
            'TARGET_CRS': target_crs,
            'OUTPUT':'memory:'
        }
    )['OUTPUT']

tile_count = 0

for tile in tile_layer.getFeatures():
    tile_count += 1
    print("Processing tile", tile_count)

    # -------- EXTRACT GRID ID AND ROUND --------
    if 'id' in tile.fields().names():
        grid_id = int(round(tile['id']))
    else:
        grid_id = tile_count

    # -------- CREATE TILE MEMORY LAYER --------
    tile_layer_temp = QgsVectorLayer(
        "Polygon?crs=" + target_crs,
        "tile",
        "memory"
    )
    prov = tile_layer_temp.dataProvider()
    new_feat = QgsFeature(tile)
    prov.addFeatures([new_feat])
    tile_layer_temp.updateExtents()

    # -------- CLIP ROADS IN MEMORY --------
    clipped_roads = processing.run(
        "native:clip",
        {
            'INPUT': roads_layer_fixed,
            'OVERLAY': tile_layer_temp,
            'OUTPUT':'memory:'
        }
    )['OUTPUT']

    # -------- CHECK IF CLIPPED ROADS HAVE FEATURES --------
    if clipped_roads.featureCount() == 0:
        print(f"Tile {grid_id} has no roads, skipping raster and JSON.")
        continue  # skip both raster and JSON

    # -------- RASTER CLIP --------
    raster_output = os.path.join(images_folder, f"image_{grid_id}.tif")
    processing.run(
        "gdal:cliprasterbymasklayer",
        {
            'INPUT': hillshade,
            'MASK': tile_layer_temp,
            'CROP_TO_CUTLINE': True,
            'OUTPUT': raster_output
        }
    )

    # -------- SAVE ROADS JSON ONLY IF RASTER IS CREATED --------
    roads_output = os.path.join(labels_folder, f"image_{grid_id}.geojson")
    QgsVectorFileWriter.writeAsVectorFormat(
        clipped_roads,
        roads_output,
        "UTF-8",
        clipped_roads.crs(),
        "GeoJSON"
    )
    print(f"Saved GeoJSON for tile {grid_id}: {roads_output}")

print("Finished! Data saved in:", output_folder)