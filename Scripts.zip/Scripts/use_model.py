"""
Run a pre-trained YOLOv11 segmentation model on training data (single picture)
"""

from ultralytics import YOLO
import numpy as np
import cv2

# load weights of the trained model
model = YOLO('/Users/leonhofmann/Desktop/MMES/Protject 2/Yolo11/runs/increased_learning_rate2/weights/best.pt')

# read training picture
img_path = '/Users/leonhofmann/Desktop/MMES/Protject 2/Yolo11/TestData/images/image_4385.png'
img = cv2.imread(img_path)

# predict segmentation using weights of the trained model
results = model.predict(
    source=img_path,
    project= '/Users/leonhofmann/Desktop/MMES/Protject 2/Yolo11/predictions',  # expliziter Ordner
    save=True,
    save_txt=True,
    save_conf=False,
    show=True
)

