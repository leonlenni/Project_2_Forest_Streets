#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Mar  9 16:27:18 2026

@author: leonhofmann
"""

#!/usr/bin/env python3
import json
from pathlib import Path
import rasterio
from rasterio.transform import Affine

# Directory of predictions and corresponding TIFF
predictions_dir = '/Users/leonhofmann/Desktop/MMES/Protject 2/Yolo11/predictions/predict2/labels' # .txt
tiff_dir = '/Users/leonhofmann/Desktop/MMES/Protject 2/Yolo11/TestData/images_raw'           # original .tif used for predictions
output_geojson_dir = '/Users/leonhofmann/Desktop/MMES/Protject 2/Yolo11/predictions/labels_worldcoordinates'

Path(output_geojson_dir).mkdir(parents=True, exist_ok=True)

# Map integer class ID to your RoadTyp if needed
class_to_roadtyp = {
    0: 0,
    1: 1,
    2: 2
}

for yolo_file in Path(predictions_dir).glob("*.txt"):
    raster_file = Path(tiff_dir) / (yolo_file.stem + ".tif")
    output_geojson_file = Path(output_geojson_dir) / (yolo_file.stem + ".geojson")

    if not raster_file.exists():
        print(f"Skipping {yolo_file.stem}, TIFF not found")
        continue
    # Open raster to get transform and image size
    with rasterio.open(raster_file) as src:
        transform = src.transform
        width = src.width
        height = src.height

    features = []

    with open(yolo_file) as f:
        for line in f:
            parts = line.strip().split()
            if len(parts) < 3:
                continue
            class_id = int(parts[0])
            coords = list(map(float, parts[1:]))
            # coords = [x1, y1, x2, y2, ...] normalized in [0,1]

            # Map normalized coordinates back to pixel coordinates
            pixel_coords = [(x * width, y * height) for x, y in zip(coords[::2], coords[1::2])]

            # Map pixel coordinates to world coordinates using raster transform
            world_coords = [tuple(~transform * (px, py)) for px, py in pixel_coords]

            feature = {
                "type": "Feature",
                "properties": {
                    "RoadTyp": class_to_roadtyp.get(class_id, 0)
                },
                "geometry": {
                    "type": "Polygon",
                    "coordinates": [world_coords]  # outer ring
                }
            }
            features.append(feature)

    geojson = {
        "type": "FeatureCollection",
        "features": features
    }

    with open(output_geojson_file, "w") as f:
        json.dump(geojson, f, indent=2)
    
    print(f"GeoJSON saved: {output_geojson_file}")